import UIKit
import Alamofire
import SwiftyJSON

class SingInViewController: UIViewController {

    @IBOutlet weak var inputPassword: UITextField!
    @IBAction func signInAction(_ sender: UIButton) {
    }
}

